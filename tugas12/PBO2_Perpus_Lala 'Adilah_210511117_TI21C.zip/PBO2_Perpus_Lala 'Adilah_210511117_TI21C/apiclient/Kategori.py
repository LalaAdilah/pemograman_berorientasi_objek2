    
 # Script Generated Using PyAthlon   
 # Created By: Freddy Wicaksono, M.Kom   
 # ===================================   
 # filename : Kategori.py   
import requests   
import json   
    
class Kategori:   
    
     def __init__(self):   
         self.__id=None   
         self.__kodekategori = None   
         self.__nama_kategori = None   
    
         self.__url = "http://localhost/appperpus/kategori_api.php"  
                        
     @property   
     def id(self):   
         return self.__id   
    
    
    
     @property   
     def kodekategori(self):   
         return self.__kodekategori   
            
     @kodekategori.setter   
     def kodekategori(self, value):   
         self.__kodekategori = value   
    
    
    
     @property   
     def nama_kategori(self):   
         return self.__nama_kategori   
            
     @nama_kategori.setter   
     def nama_kategori(self, value):   
         self.__nama_kategori = value   
    
    
    
    
     def get_all(self):   
         payload ={}   
         headers = {'Content-Type': 'application/json'}   
         response = requests.get(self.__url, json=payload, headers=headers)   
         return response.text   
    
    
    
     def get_by_kodekategori(self, kodekategori):   
         url = self.__url+"?kodekategori="+ kodekategori  
         payload = {}   
         headers = {'Content-Type': 'application/json'}   
         response = requests.get(url, json=payload, headers=headers)   
         data = json.loads(response.text)   
         for item in data:   
             self.__id = item['id']   
             self.__kodekategori = item['kodekategori']   
             self.__nama_kategori = item['nama_kategori']   
         return data   
    
    
     def simpan(self):   
         payload = {   
             "kodekategori":self.__kodekategori,   
             "nama_kategori":self.__nama_kategori   
    
             }   
         headers = {'Content-Type': 'application/x-www-form-urlencoded'}   
         response = requests.post(self.__url, data=payload, headers=headers)   
         return response.text   
    
    
    
     def update_by_kodekategori(self,kodekategori ):   
         url = self.__url+"?kodekategori="+ kodekategori  
         payload = {   
             "kodekategori":self.__kodekategori,   
             "nama_kategori":self.__nama_kategori   
    
             }   
         headers = {'Content-Type': 'application/x-www-form-urlencoded'}   
         response = requests.put(url, data=payload, headers=headers)   
         return response.text   
    
    
    
     def delete_by_kodekategori(self,kodekategori):   
         url = self.__url+"?kodekategori="+ kodekategori  
         headers = {'Content-Type': 'application/json'}   
         payload={}   
         response = requests.delete(url, json=payload, headers=headers)   
         return response.text   
    
