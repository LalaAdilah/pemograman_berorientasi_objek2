    
 # Script Generated Using PyAthlon   
 # Create By Freddy Wicaksono, M.Kom   
 # =================================   
 # Nama File : FrmPeminjaman.py   
import tkinter as tk   
import json   
    
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox   
from Peminjaman import *   
    
class FrmPeminjaman:   
        
     def __init__(self, parent, title):   
         self.parent = parent          
         self.parent.geometry("450x450")   
         self.parent.title(title)   
         self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)   
         self.ditemukan = None   
         self.aturKomponen()   
         self.onReload()   
            
     def aturKomponen(self):   
         mainFrame = Frame(self.parent, bd=10)   
         mainFrame.pack(fill=BOTH, expand=YES)   
         Label(mainFrame, text='NOMORBUKTI:').grid(row=0, column=0,   
             sticky=W, padx=5, pady=5)   
         Label(mainFrame, text='TGL_PINJAM:').grid(row=1, column=0,   
             sticky=W, padx=5, pady=5)   
         Label(mainFrame, text='KODEANGGOTA:').grid(row=2, column=0,   
             sticky=W, padx=5, pady=5)   
         Label(mainFrame, text='KODEBUKU1:').grid(row=3, column=0,   
             sticky=W, padx=5, pady=5)   
         Label(mainFrame, text='KODEBUKU2:').grid(row=4, column=0,   
             sticky=W, padx=5, pady=5)   
         Label(mainFrame, text='TGLHRSKEMBALI:').grid(row=5, column=0,   
             sticky=W, padx=5, pady=5)   
         Label(mainFrame, text='TGL_DIKEMBALIKAN:').grid(row=6, column=0,   
             sticky=W, padx=5, pady=5)   
         Label(mainFrame, text='STATUS_PINJAM:').grid(row=7, column=0,   
             sticky=W, padx=5, pady=5)   
    
    
    
         # Textbox   
         self.txtNomorbukti = Entry(mainFrame)    
         self.txtNomorbukti.grid(row=0, column=1, padx=5, pady=5)   

        # Textbox   
         self.txtTanggalPinjam = Entry(mainFrame)    
         self.txtTanggalPinjam.grid(row=1, column=1, padx=5, pady=5)   
    
    
         # Textbox   
         self.txtKodeanggota = Entry(mainFrame)    
         self.txtKodeanggota.grid(row=2, column=1, padx=5, pady=5)   
    
    
         # Textbox   
         self.txtKodebuku1 = Entry(mainFrame)    
         self.txtKodebuku1.grid(row=3, column=1, padx=5, pady=5)   
    
    
         # Textbox   
         self.txtKodebuku2 = Entry(mainFrame)    
         self.txtKodebuku2.grid(row=4, column=1, padx=5, pady=5)   
    
    
         # Textbox   
         self.txtStatus_pinjam = Entry(mainFrame)    
         self.txtStatus_pinjam.grid(row=7, column=1, padx=5, pady=5)   
    
    
         # Button   
         self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)   
         self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)   
         self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)   
         self.btnClear.grid(row=1, column=3, padx=5, pady=5)   
         self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)   
         self.btnHapus.grid(row=2, column=3, padx=5, pady=5)   
    
         # define columns   
         columns = ('id','nomorbukti','tgl_pinjam','kodeanggota','kodebuku1','kodebuku2','tglhrskembali','tgl_dikembalikan','status_pinjam')   
    
    
         self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')   
         # define headings   
    
         self.tree.heading('id', text='ID')   
         self.tree.column('id', width="50")   
    
    
         self.tree.heading('nomorbukti', text='NOMORBUKTI')   
         self.tree.column('nomorbukti', width="100")   
    
    
         self.tree.heading('tgl_pinjam', text='TGL_PINJAM')   
         self.tree.column('tgl_pinjam', width="90")   
    
    
         self.tree.heading('kodeanggota', text='KODEANGGOTA')   
         self.tree.column('kodeanggota', width="900")   
    
    
         self.tree.heading('kodebuku1', text='KODEBUKU1')   
         self.tree.column('kodebuku1', width="100")   
    
    
         self.tree.heading('kodebuku2', text='KODEBUKU2')   
         self.tree.column('kodebuku2', width="100")   
    
    
         self.tree.heading('tglhrskembali', text='TGLHRSKEMBALI')   
         self.tree.column('tglhrskembali', width="90")   
    
    
         self.tree.heading('tgl_dikembalikan', text='TGL_DIKEMBALIKAN')   
         self.tree.column('tgl_dikembalikan', width="90")   
    
    
         self.tree.heading('status_pinjam', text='STATUS_PINJAM')   
         self.tree.column('status_pinjam', width="150")   
    
    
         # set tree position   
         self.tree.place(x=0, y=200)   
    
    
            
     def onClear(self, event=None):   
    
         self.txtNomorbukti.delete(0,END)   
         self.txtNomorbukti.insert(END,"")   
         self.txtKodeanggota.delete(0,END)   
         self.txtKodeanggota.insert(END,"")   
         self.txtKodebuku1.delete(0,END)   
         self.txtKodebuku1.insert(END,"")   
         self.txtKodebuku2.delete(0,END)   
         self.txtKodebuku2.insert(END,"")   
         self.txtStatus_pinjam.delete(0,END)   
         self.txtStatus_pinjam.insert(END,"")   
         self.btnSimpan.config(text="Simpan")   
         self.onReload()   
         self.ditemukan = False   
            
     def onReload(self, event=None):   
         # get data peminjaman   
         obj = Peminjaman()   
         result = obj.get_all()   
         parsed_data = json.loads(result)   
         for item in self.tree.get_children():   
             self.tree.delete(item)   
            
         for i, d in enumerate(parsed_data):   
             self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["nomorbukti"],d["tgl_pinjam"],d["kodeanggota"],d["kodebuku1"],d["kodebuku2"],d["tglhrskembali"],d["tgl_dikembalikan"],d["status_pinjam"]))   
    
    
    
    
     def onCari(self, event=None):   
         nomorbukti = self.txt.get()   
         obj = Peminjaman()   
         a = obj.get_by_nomorbukti(nomorbukti)   
         if(len(a)>0):   
             self.TampilkanData()   
             self.ditemukan = True   
         else:   
             self.ditemukan = False   
             messagebox.showinfo("showinfo", "Data Tidak Ditemukan")   
    
    
    
     def TampilkanData(self, event=None):   
         nomorbukti = self.txt.get()   
         obj = Peminjaman()   
         res = obj.get_by_nomorbukti(nomorbukti)   
    
         self.txtNomorbukti.delete(0,END)   
         self.txtNomorbukti.insert(END,obj.nomorbukti)   
         self.txtKodeanggota.delete(0,END)   
         self.txtKodeanggota.insert(END,obj.kodeanggota)   
         self.txtKodebuku1.delete(0,END)   
         self.txtKodebuku1.insert(END,obj.kodebuku1)   
         self.txtKodebuku2.delete(0,END)   
         self.txtKodebuku2.insert(END,obj.kodebuku2)   
         self.txtStatus_pinjam.delete(0,END)   
         self.txtStatus_pinjam.insert(END,obj.status_pinjam)   
         self.btnSimpan.config(text="Update")   
                     
     def onSimpan(self, event=None):   
         # get the data from input   
         nomorbukti = self.txtNomorbukti.get()   
         tgl_pinjam = self.txtTgl_pinjam.get()   
         kodeanggota = self.txtKodeanggota.get()   
         kodebuku1 = self.txtKodebuku1.get()   
         kodebuku2 = self.txtKodebuku2.get()   
         tglhrskembali = self.txtTglhrskembali.get()   
         tgl_dikembalikan = self.txtTgl_dikembalikan.get()   
         status_pinjam = self.txtStatus_pinjam.get()   
    
         # create new Object   
         obj = Peminjaman()   
         obj.nomorbukti = nomorbukti   
         obj.tgl_pinjam = tgl_pinjam   
         obj.kodeanggota = kodeanggota   
         obj.kodebuku1 = kodebuku1   
         obj.kodebuku2 = kodebuku2   
         obj.tglhrskembali = tglhrskembali   
         obj.tgl_dikembalikan = tgl_dikembalikan   
         obj.status_pinjam = status_pinjam   
    
         if(self.ditemukan==False):   
             # save the record   
             res = obj.simpan()   
         else:   
             # update the record   
             res = obj.update_by_nomorbukti(nomorbukti)   
    
         # read data in json format   
         data = json.loads(res)   
         status = data["status"]   
         msg = data["message"]   
    
         # display json data into messagebox   
         messagebox.showinfo("showinfo", status+', '+msg)   
    
         #clear the form input   
         self.onClear()   
    
    
    
    
    
     def onDelete(self, event=None):   
         nomorbukti = self.txt.get()   
         obj = Peminjaman()   
         obj.nomorbukti = nomorbukti    
         if(self.ditemukan==True):   
             res = obj.delete_by_nomorbukti(nomorbukti)   
         else:   
             messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")   
                
         # read data in json format   
         data = json.loads(res)   
         status = data["status"]   
         msg = data["message"]   
            
         # display json data into messagebox   
         messagebox.showinfo("showinfo", status+', '+msg)   
            
         self.onClear()   
                
     def onKeluar(self, event=None):   
         # memberikan perintah menutup aplikasi   
         self.parent.destroy()   
    
    
    
if __name__ == '__main__':   
     root2 = tk.Tk()   
     aplikasi = FrmPeminjaman(root2, "Aplikasi Data Peminjaman")   
     root2.mainloop()   
    
